import React from 'react'
import '../../style/UpdateHistory.css'

function UpdateHistory()
{
    return(
    <button class="UpdateHistory">
      <div>Upload History</div>
    </button>
    )
}

export default UpdateHistory